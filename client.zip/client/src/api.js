import axios from "axios";

const API_URL = "http://localhost:5000/api";
//axios
export const loginUser = (userData) => axios.post(`${API_URL}/auth/login`, userData);
export const registerUser = (userData) => axios.post(`${API_URL}/auth/register`, userData);
export const fetchItems = () => axios.get(`${API_URL}/items`);
export const addItem = (itemData) => axios.post(`${API_URL}/items`, itemData);
