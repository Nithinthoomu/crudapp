import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import '../Dashboard.css';  // Import the here CSS file

const Dashboard = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [editingItem, setEditingItem] = useState(null);

  useEffect(() => {
    const userId = localStorage.getItem("userId");
    if (!userId) {
      navigate("/");  
    } else {
      fetchItems(userId); 
    }
  }, [navigate]);

  const fetchItems = async (userId) => {
    try {
      const res = await axios.get("http://localhost:5000/api/items", {
        headers: { Authorization: `Bearer ${userId}` }
      });
      setItems(res.data);
    } catch (error) {
      console.error("Error fetching items:", error);
    }
  };

  const handleAddItem = async () => {
    const userId = localStorage.getItem("userId");
    if (!userId) {
      alert("User not authenticated!");
      return;
    }

    try {
      const res = await axios.post("http://localhost:5000/api/items", { title, description, userId });
      setItems([...items, res.data]);
      setTitle("");
      setDescription("");
    } catch (error) {
      alert("Error adding item.");
    }
  };

  const handleEditItem = async () => {
    if (!title || !description) {
      alert("Please fill in both fields.");
      return;
    }

    try {
      const res = await axios.put(`http://localhost:5000/api/items/${editingItem._id}`, { title, description });
      setItems(items.map(item => item._id === editingItem._id ? res.data : item)); 
      setEditingItem(null);
      setTitle("");
      setDescription("");
    } catch (error) {
      alert("Error updating item.");
    }
  };

  const handleDeleteItem = async (itemId) => {
    try {
      await axios.delete(`http://localhost:5000/api/items/${itemId}`);
      setItems(items.filter(item => item._id !== itemId));
    } catch (error) {
      alert("Error deleting item.");
    }
  };

  const handleSelectItemForEdit = (item) => {
    setEditingItem(item);
    setTitle(item.title);
    setDescription(item.description);
  };

  return (
    <div className="dashboard-container">
      <h2>Dashboard</h2>

      <form className="form-container">
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <input
          type="text"
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        {editingItem ? (
          <button type="button" className="update-button" onClick={handleEditItem}>
            Update Item
          </button>
        ) : (
          <button type="button" className="add-button" onClick={handleAddItem}>
            Add Item
          </button>
        )}
      </form>

      <div className="item-list">
        {items.map((item) => (
          <div className="item-box" key={item._id}>
            <div className="item-content">
              <h4>{item.title}</h4>
              <p>{item.description}</p>
            </div>
            <div className="button-group">
              <button
                className="edit-button"
                onClick={() => handleSelectItemForEdit(item)}
              >
                Edit
              </button>
              <button
                className="delete-button"
                onClick={() => handleDeleteItem(item._id)}
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
