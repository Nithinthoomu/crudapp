const Footer = () => {
  //footer
    return (
      <footer style={{ textAlign: "center", padding: "10px", background: "#282c34", color: "#fff", marginTop: "20px" }}>
        <p>© {new Date().getFullYear()} MERN App</p>
      </footer>
    );
  };
  
  export default Footer;
  