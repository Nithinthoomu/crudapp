import { useNavigate } from "react-router-dom";
import { useState } from "react";
import "../Navbar.css";
//navbar
const Navbar = () => {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(
    localStorage.getItem("userId") !== null
  );

  const handleLogout = () => {
    localStorage.removeItem("userId"); // Remove user data
    setIsLoggedIn(false);
    navigate("/"); // Redirect to login page
  };

  return (
    <nav className="navbar">
      <div className="logo" onClick={() => navigate("/")}>MyApp</div>
      <ul className="nav-links">
        <li onClick={() => navigate("/")}>Home</li>
        <li onClick={() => navigate("/dashboard")}>Dashboard</li>
        <li onClick={() => navigate("/about")}>About</li>
      </ul>
      {isLoggedIn ? (
        <button className="logout-btn" onClick={handleLogout}>Logout</button>
      ) : (
        <button className="login-btn" onClick={() => navigate("/")}>Login</button>
      )}
    </nav>
  );
};

export default Navbar;
